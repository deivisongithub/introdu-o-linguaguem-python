# Matriz 5 x 5
# Aluno: Deivison Rodrigues Jordão
for i in range(1,6):
    print()
    for I in range(1,6):
        print("X",end=' ')