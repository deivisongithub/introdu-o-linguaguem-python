# Aluno: Deivison rodrigues jordão
 # programa para converter de °F para °C 
  # C=5*(F-32)/9
Fahrenheit = float(input('informe a temperatura em Fahrenheit: '))

Celcius = 5*( Fahrenheit - 32)/9

print("\n A temperatura em Celcius e : %.2f" %Celcius)
